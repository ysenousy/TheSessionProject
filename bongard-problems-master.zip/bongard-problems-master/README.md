# bongard-problems
all bongard problems dataset
